import 'regenerator-runtime';
import '../styles/main.css';
import '../styles/responsive.css';


async function getDataAsync() {
    try {
        const response = await fetch('/data/DATA.json');
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

async function displayRestaurants() {
    const restaurantList = document.getElementById('tes');
    const data = await getDataAsync();

    if (data && data.restaurants) {
        data.restaurants.forEach(restaurant => {
            const list_item = document.createElement('div');
            list_item.classList.add('list_item');
            list_item.innerHTML = `
            <div class="item-container">
            <img class="list_item_thumb" src="${restaurant.pictureId}" alt="${restaurant.name}" title="${restaurant.name}">
            <div class="city">${restaurant.city}</div>
         </div>
                <div class="list_item_content">
                    <p class="list_item_rating">
                        Rating : 
                        <a href="" class="list_item_rating_value">${restaurant.rating}</a>
                    </p>
                    <h1 class="list_item_title"><a href="">${restaurant.name}</a></h1>
                    <div class="list_item_desc">${restaurant.description.slice(0, 150)}...</div>
                </div>
            `;

            restaurantList.appendChild(list_item);
        });
    }
}

displayRestaurants();

document.addEventListener("DOMContentLoaded", function() {
    const menu = document.querySelector('#menu');
    const mainHero = document.querySelector('.main-hero');
    const main = document.querySelector('main');
    const drawer = document.querySelector('#drawer');

    if (menu) {
        menu.addEventListener('click', function (event) {
            drawer.classList.toggle('open');
            event.stopPropagation();
        });
    }

    if (mainHero) {
        mainHero.addEventListener('click', function () {
            drawer.classList.remove('open');
        });
    }

    if (main) {
        main.addEventListener('click', function () {
            drawer.classList.remove('open');
        });
    }
});
